package p8.demo.p8sokoban.State;

import android.widget.Button;
import android.widget.TextView;

/**
 * Created by IKARUGA on 07/11/2016.
 */

public class Global {
    public static Button winscreen;
    public static Button menubtn;
    public static TextView numScore;
    public static int levelstate;
    public static boolean winsoko = false;
    public static boolean menu_state = false;
    public static int hi_score = 0;
    public static int final_score = 999;
    public static int final_score2 = 999;
}
